Real NASA chatterer pack created by KingNeberkenezer
See http://forum.kerbalspaceprogram.com/index.php?/topic/83290-11-chatterer-v098-keep-talking-19-apr-2016/&do=findComment&comment=2538340

Version: 1