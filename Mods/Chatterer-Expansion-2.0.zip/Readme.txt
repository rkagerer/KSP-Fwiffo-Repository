Additional chatter sounds for Chatterer

AUTHOR:
Created by Fwiffo, by manually editing / reversing sounds from the NASA chatterer pack put together by KingNeberkenezer [BeeMeister on Twitch]

VERSION: 2

INSTRUCTIONS:

After dropping the content of GameData into your KSP installation, run KSP, go to a MANNED pod (important),
and open Chatterer.  Ensure option to show Advanced settings is selected.  Then go to the Chatter tab,
type in "expansion" and click Load.

SEE ALSO:

  http://forum.kerbalspaceprogram.com/index.php?/topic/83290-11-chatterer-v098-keep-talking-19-apr-2016/&do=findComment&comment=2562690

  http://forum.kerbalspaceprogram.com/index.php?/topic/83290-11-chatterer-v098-keep-talking-19-apr-2016/&do=findComment&comment=2538340
