﻿// Decompiled with help from JetBrains decompiler
// Type: RCSBuildAid.CrossMarkGraphic
// Assembly: RCSBuildAid, Version=0.7.7.34644, Culture=neutral, PublicKeyToken=null
// MVID: AE3A67B1-2C24-4531-AB08-ED92D05EEF04
// Assembly location: RCSBuildAid.dll

using System.Collections.Generic;
using UnityEngine;

namespace RCSBuildAid {

  public class CrossMarkGraphic : LineBase {
    private const float scale = 1.2f;

    protected override void Awake() {
      base.Awake();
      for (int index = 0; index < 6; ++index)
        lines.Add(newLine());
      using (List<LineRenderer>.Enumerator enumerator = this.lines.GetEnumerator()) {
        while (enumerator.MoveNext()) {
          LineRenderer current = enumerator.Current;
          current.useWorldSpace = false;
          current.SetVertexCount(2);
          current.SetPosition(0, Vector3.zero);
        }
      }
      lines[0].SetPosition(1, Vector3.forward * 1.2f);
      lines[1].SetPosition(1, Vector3.forward * -1.2f);
      lines[2].SetPosition(1, Vector3.right * 1.2f);
      lines[3].SetPosition(1, Vector3.right * -1.2f);
      lines[4].SetPosition(1, Vector3.up * 1.2f);
      lines[5].SetPosition(1, Vector3.up * -1.2f);
    }

    protected override void LateUpdate() {
      base.LateUpdate();
      double num1 = 0.0;
      double num2 = 0.0500000007450581;
      Vector3 localScale = transform.localScale;
      double num3 = localScale.magnitude;
      double num4 = num2 * num3;
      this.setWidth((float)num1, (float)num4);
    }
  }

}
