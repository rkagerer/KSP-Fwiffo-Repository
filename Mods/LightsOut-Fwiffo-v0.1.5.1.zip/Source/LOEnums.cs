﻿using System;

public enum EditorLevel {
	Level1 = 1,
	Level2 = 2,
	Level3 = 3
}

public enum EditorTime {
	Day = 1,
	Night = 2
}